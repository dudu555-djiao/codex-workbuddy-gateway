# 桌面队列执行会话

## v0.6.0 多项目原生接入

默认调用 `workbuddy_ensure_workspace({workspace:"项目绝对目录"})`，或 `send_task` 直接传 `workspace`。通过本机 CDP 和 WorkBuddy 原生 `workspace:initialize`、`session:create`、`session:rename` 接口创建会话，并核对原生注册。用户不需要先打开聊天或粘贴安装指令；登录、输入与权限仍沿用 WorkBuddy 的原生流程。此处创建的是目录对应的本地执行会话，不是云端团队空间。

每个项目独立保存会话映射，重复调用复用。`ensure_workspace` 的 `sessionId` 可选择同目录已有的真实会话。切换选择不改变旧任务和返工的身份；旧会话仍会被监督。一个 LaunchAgent 逐轮监督全部已登记会话，各会话单独校验忙闲、租约和唤醒回执。它允许不同目录的原生执行并存，实际并发仍受 WorkBuddy 能力和额度约束。

原来的持久服务配置保留为默认入口。业务项目路由另存于本机任务记录目录的 `workspace-workers.sqlite`，不会直接写 WorkBuddy 数据库。创建前预留原生 ID；不确定的创建不得自动重发，发现对应真实记录后可复用恢复。已登记多个项目时，派工须指明目录或会话，以免使用旧默认目录。

以下持久安装及临时监听章节保留 v0.4.1 的历史操作方法。v0.6.0 默认走上面的原生接入。

v0.4.1 在本机任务队列上增加 macOS 持久服务，保留原有临时监听模式。本轮 WorkBuddy 5.7.6 已实际安装并激活 LaunchAgent；运行中自动派工、普通方式重开、完全关闭后自动启动、裸启动没有调试端口时自动正常重启一次，以及回复结束后的同会话返工均实测通过。四项小文件创建与一项返工已核对原生工具、队列归属及实际文件；98 项自动化测试通过。用户登录恢复和系统重启未实测。

## 持久模式：首次安装一次

打开 WorkBuddy 专用桌面对话，先发送一条普通消息。Codex 读取 `workbuddy_health.workerCandidates`，按实际工作目录核对会话编号。历史候选不是正在运行的监听器，也不要随便取最新项。

调用 `workbuddy_prepare_worker({sessionId, persistent: true})`，将返回的完整 `prompt` 一次粘贴到同一个真实 WorkBuddy 对话。该工具只生成安装指令，尚未安装或唤醒。WorkBuddy 自己使用 Bash 执行指令中的命令：

```bash
./bin/workbuddy-service install --session-id '真实会话编号' --workspace '真实绝对工作目录' --cdp-port 18491
```

以工具生成的实际路径为准，项目必须已构建并保留在稳定位置。安装保存 sessionId/workspace/项目路径，写入用户级 LaunchAgent（`RunAtLoad` / `KeepAlive`），并设置原生应用下次启动的调试端口环境。服务经仅回环 CDP 连接 WorkBuddy 5.7.6 的原生 MessageChannel RPC；无需读取登录凭据、改 `app.asar`、点击 UI 或运行另一个模型 Host。

服务在需要时自动启动原生应用，或等当前会话空闲后正常重启一次以启用端口；这两种场景本轮均已实测，不要求用户手工反复重启。安装与绑定可用 `./bin/workbuddy-service status` 核对。空队列时没有等待中的 helper 是正常状态。下次任务进入队列后，服务连接原生应用，以 `session:sendMessage` 给绑定的专用会话发送 queuewake 提示；WorkBuddy 再用自己的工具运行 helper，真实领取并执行。

正常退出应用、重新打开及后续登录后，服务使用原有绑定，不需要重新粘贴 bootstrap。电脑关机或用户登出时不会执行；下次登录恢复仍依赖有效 WorkBuddy 登录、权限及原生接口兼容性。应用升级后须重新核对兼容性。只下载独立 Skill 不会安装此服务，仍需完整 Gateway。

```bash
./bin/workbuddy-service status
./bin/workbuddy-service uninstall
```

卸载停止服务并移除其启动注册，保留业务任务记录。不要手工删任务库来处理连接问题。

## 临时模式：本次监听

省略 `persistent: true` 时，`workbuddy_prepare_worker({sessionId})` 返回临时监听指令，发到同一个真实桌面对话。该 prompt 让 WorkBuddy 用自己的 Bash 运行本机 helper；helper 只传队列任务和回报，不执行任务目标。Codex 自己调用 `claim/progress/report` 会因不是 WorkBuddy 桌面进程而拒绝。

如需在终端生成启动指令，可以在完整项目目录执行：

```bash
./bin/workbuddy-worker bootstrap --session-id '真实会话编号'
```

这一步也只生成临时指令，不安装服务或启动监听。不要修改 WorkBuddy 原生数据库来伪造新会话。

## 自动传递

Codex 的 `send_task` 将任务写入 SQLite 和私有执行记录。WorkBuddy 的 `claim` 最多等待 55 秒，领取后得到完整目标、约束、验收条件与本轮凭证。WorkBuddy 用原生工具执行，并调用 `report` 回报真实结果和路径。

每轮凭证只用于那一轮，旧报告和错误会话不能覆盖新返工结果。helper 校验进程来自桌面应用、会话已注册、凭证匹配；会话编号由启动指令提供，需要人工或桌面观察核对所在对话，不能将其解释为宿主提供的会话级加密认证。

Codex 读取回报后独立检查实际成果。需要修改时，`continue_task` 保留原会话、目标、约束及验收要求，并排入新轮次。持久模式在回复结束、原生会话空闲后可以自动唤醒返工，无需维持 claim 空等；临时模式则依赖继续领取。不合格结果只能进入 review 或 blocked，不能凭一句 completed 宣布验收。

## 空闲、重启与异常

持久服务在空队列时只检查本机记录，不给模型发送空等消息。每次唤醒后 WorkBuddy 领取、执行和回报，再运行一次 `claim --wait-seconds 0`：有新任务就继续，空队列就结束本次回复，等待下次按需唤醒。持久模式不做四轮空等；临时模式仍默认连续四次空等（各约50秒）后退出，领取任务后重置计数。不并行重复启动 claim。

只有临时模式在结束当前回复、退出或停止领取后需要重新发送启动指令。持久模式由本机服务按需原生唤醒。正常退出重开后的新任务可自动恢复；若应用在已领取任务执行中崩溃，或唤醒提交的结果不确定，先检查原会话、轮次和已有产物，明确记录阻塞并决定恢复，不能静默重执行。服务不对执行中会话重叠派工，不因连接暂时失效重复发送不确定的唤醒。

已领取任务因网络中断而超过期限时，操作员核查原生会话的失败记录和已有文件后，可运行：

```sh
bin/workbuddy-service recover --task-id TASK_ID --attempt-id ATTEMPT_ID --reason '已检查的具体中断原因和保留成果'
```

该命令通过原生 RPC 确认原会话在原目录空闲，拒绝执行中、等待输入、离线、目录变更和非当前轮次。它保留原 claim、失败记录和产物，只关闭过期租约，并保存 `recovery.json` 审计；不会把任务标为完成，也不派新任务。随后使用 `continue_task` 在同一 taskId/sessionId 建立新轮次，要求 WorkBuddy 核验已有成果并使用新领取凭证回报。旧轮次仍不能回报。本机服务不会自动执行这个恢复步骤。

模型在 WorkBuddy 中选择。队列拒绝远程模型切换和自动新建会话。权限和输入沿用原生 UI；`respond_task` 不为队列绕过桌面授权。取消是协作请求，执行器需要检查并停下，已经写入的文件不会自动回滚。

过程信息是 WorkBuddy 主动填写的回报，桥接器不自动采集完整工具轨迹。`ready` / `online` 仍表示正在等任务的 helper；持久服务安装绑定匹配且心跳有效、暂时没有 helper 时，health 返回 `persistent_service_idle`，这是正常空闲，不需要 bootstrap。绑定生效时省略无关历史候选，只返回服务绑定信息；不同任务库不继承其他库的服务绑定。服务健康不保证任务已完成，仍按真实领取及成果核对，也不自动唤醒退出的 Codex。

## 已有临时模式实机验证

2026-10-08，Mac 解锁后完成了以下实机步骤：

1. 在既有原生准备会话中通过桌面操作发送一次队列启动指令。具体清单目标已经通过 MCP 排入队列，不在界面重复投递。
2. WorkBuddy 原生 Bash 运行 helper，进程来源校验通过并领取任务。桌面可见 Write 创建清单、Read 读回；真实回报进入 needs_review。
3. Codex 只读检查实际文件，内容与第一轮要求逐字一致。
4. Codex 通过 MCP continue 派发“只改第三条”的反馈，没有再次点击发送具体任务。WorkBuddy 同一原生会话继续 claim，自动收到返工，用 Edit 修改并 Read 核对，回报新轮次。
5. Codex 独立比较，确认只有第三条改变，其余内容与末尾换行保持一致，随后保存 accepted 及真实文件检查证据。

原生成果位于用户本机全新测试目录。会话 ID、用户路径、轮次凭证与原始日志只保留本机，公开包不包含这些内容。实测每次调用启动新的 MCP 客户端，记录在重连后仍可读；已驻留的 Codex MCP 必须重新加载新版。

这些历史测试验证了临时队列的文件创建、同会话返工，以及官方价格查询中的原生 WebSearch/WebFetch 与文件修改。

## v0.4.1 持久模式实机验证

本轮在已有真实 WorkBuddy 5.7.6 专用会话完成，无 Computer Use：

1. WorkBuddy 用自己的 Bash 执行持久安装指令，LaunchAgent 激活，绑定仍为原生会话与工作目录。
2. Codex 排入新任务，无需再次粘贴。服务原生唤醒，WorkBuddy 实际 Write 创建文件、Read 核对；Codex 检查队列身份、轮次和真实内容后验收。
3. 原生应用正常退出，再通过普通 `open -a WorkBuddy` 重开，没有显式注入环境；下一项任务自动完成，沿用同一会话。
4. 回复结束且原生 SDK 空闲后，Codex continue 排入返工。服务自动唤醒原会话，WorkBuddy 用 Edit 修改、Read 核对真实文件，Codex 比较后验收。
5. 确认原生应用完全关闭且没有主进程，再排新任务；服务自动启动原生应用，同一会话 Write/Read、回报与真实文件内容核对通过。
6. 移除启动调试环境后直接裸启动原生应用，确认端口不存在，再排任务；服务正常退出并重启应用一次以启用端口，同一会话 Write/Read、回报与实际内容核对通过。

本轮共四项小文件创建和一项返工，无业务搜索或视频测试；98 项自动化测试通过。持久唤醒指令回报后只做一次零等待领取，空队列不进入四次模型空等。用户登出再登录与系统重启未实测。中断不重执行由自动化覆盖，不能将正常退出重开结果当作实际崩溃恢复证明；步骤见 [验收说明](USER_ACCEPTANCE.md)。私人会话、路径、唤醒标记和原始日志不进入公开包。
