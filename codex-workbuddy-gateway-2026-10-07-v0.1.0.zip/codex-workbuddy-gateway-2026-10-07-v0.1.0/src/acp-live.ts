import fs from "node:fs";
import path from "node:path";
import { execFileSync } from "node:child_process";
import { Config } from "./config.js";

export interface LiveEndpoint {
  baseUrl: string;
  pid: number;
  sessionId: string;
  cwd?: string;
  sessionFile: string;
}

export interface AcpRunResult {
  text: string;
  stopReason?: string;
}

export type AcpPermissionMode = "deny" | "allow_once";

interface AcpCredentials {
  connectionId: string;
  sessionToken?: string;
}

const LOOPBACK_HOSTS = new Set(["127.0.0.1", "localhost", "::1"]);
const MAX_SESSION_FILE_BYTES = 64 * 1024;
const MAX_OUTPUT_CHARS = 1_000_000;

/** Discover and use the interactive ACP session owned by WorkBuddy's desktop client. */
export class AcpLiveClient {
  private credentials?: AcpCredentials;
  private connectedEndpoint?: LiveEndpoint;
  private aborted = false;

  constructor(
    private readonly config: Config,
    private readonly permissionMode: AcpPermissionMode = "deny",
    private readonly fetchImpl: typeof fetch = globalThis.fetch,
  ) {}

  static discover(config: Config): LiveEndpoint {
    const sessionsDir = path.join(config.workbuddyConfigDir, "sessions");
    let files: string[];
    try {
      files = fs.readdirSync(sessionsDir).filter((name) => name.endsWith(".json"));
    } catch {
      throw new Error(`WorkBuddy interactive session directory was not found: ${sessionsDir}`);
    }
    const candidates: Array<LiveEndpoint & { heartbeat: number }> = [];
    const now = Date.now();
    for (const name of files) {
      const filename = path.join(sessionsDir, name);
      try {
        const stat = fs.statSync(filename);
        if (!stat.isFile() || stat.size > MAX_SESSION_FILE_BYTES) continue;
        const value = JSON.parse(fs.readFileSync(filename, "utf8")) as Record<string, unknown>;
        // Only interactive rows represent an existing conversation in the desktop UI.
        if (value.kind !== "interactive") continue;
        const pid = value.pid;
        const sessionId = value.sessionId;
        const endpoint = value.endpoint ?? value.url;
        const heartbeat = value.lastHeartbeat ?? value.updatedAt;
        if (!Number.isInteger(pid) || Number(pid) <= 0 || typeof sessionId !== "string" || !sessionId.trim()) continue;
        if (typeof endpoint !== "string") continue;
        const baseUrl = validateLoopbackUrl(endpoint);
        const heartbeatNumber = typeof heartbeat === "number" ? heartbeat : Number(heartbeat);
        // The registry can retain stale rows after a worker exits. A generous two-minute
        // bound avoids selecting one while allowing normal desktop heartbeat jitter.
        if (!Number.isFinite(heartbeatNumber) || heartbeatNumber <= 0 || now - heartbeatNumber > 120_000 || heartbeatNumber - now > 120_000) continue;
        try { process.kill(Number(pid), 0); } catch { continue; }
        const cwd = typeof value.cwd === "string" && value.cwd.trim() ? value.cwd : undefined;
        candidates.push({ baseUrl, pid: Number(pid), sessionId: sessionId.trim(), cwd, sessionFile: filename, heartbeat: heartbeatNumber });
      } catch { /* ignore an incomplete or stale session file */ }
    }
    const selected = candidates.sort((a, b) => b.heartbeat - a.heartbeat)[0];
    if (!selected) throw new Error("No live WorkBuddy interactive session was found. Open a conversation in WorkBuddy and retry.");
    const { heartbeat: _heartbeat, ...endpoint } = selected;
    return endpoint;
  }

  async health(): Promise<{ endpoint: LiveEndpoint; online: boolean }> {
    const endpoint = AcpLiveClient.discover(this.config);
    const response = await this.fetchImpl(`${endpoint.baseUrl}/api/v1/acp/connect`, {
      method: "POST",
      headers: { accept: "application/json", "x-codebuddy-request": "1" },
      signal: AbortSignal.timeout(this.config.requestTimeoutMs),
    });
    if (!response.ok) throw new Error(`WorkBuddy ACP health probe failed (${response.status})`);
    const payload = await response.json() as Record<string, unknown>;
    const data = payload.data && typeof payload.data === "object" ? payload.data as Record<string, unknown> : payload;
    if (typeof data.connectionId !== "string" || !data.connectionId) throw new Error("WorkBuddy ACP health probe returned no connectionId");
    const headers: Record<string, string> = { accept: "application/json", "x-codebuddy-request": "1", "acp-connection-id": data.connectionId };
    if (typeof data.sessionToken === "string") headers["acp-session-token"] = data.sessionToken;
    // A health probe should not leave an idle ACP connection behind.
    await this.fetchImpl(`${endpoint.baseUrl}/api/v1/acp`, { method: "DELETE", headers }).catch(() => undefined);
    return { endpoint, online: true };
  }

  async run(prompt: string, sessionId?: string, timeoutMs = 300_000): Promise<AcpRunResult> {
    if (!prompt.trim()) throw new Error("WorkBuddy ACP prompt cannot be empty");
    const endpoint = AcpLiveClient.discover(this.config);
    if (sessionId && sessionId !== endpoint.sessionId) {
      throw new Error("The requested WorkBuddy session is no longer the active desktop session");
    }
    try {
      await this.connect(endpoint);
      await this.rpc(endpoint, "initialize", {
        protocolVersion: 1,
        clientInfo: { name: "codex-workbuddy-gateway", version: "0.2.0" },
        clientCapabilities: {},
      }, 30_000);
      try {
        return await this.prompt(endpoint, endpoint.sessionId, prompt, timeoutMs);
      } catch (error) {
        // Some WorkBuddy versions keep the interactive worker in a prewarm
        // pool and require one session/load before the first prompt. Retry
        // exactly once; normal prompts must never replay the full history.
        const message = error instanceof Error ? error.message : String(error);
        if (!/session not found/i.test(message)) throw error;
        this.activateSession(endpoint.sessionId);
        await this.rpc(endpoint, "session/load", {
          sessionId: endpoint.sessionId,
          cwd: endpoint.cwd ?? "",
          mcpServers: [],
        }, 60_000);
        return await this.prompt(endpoint, endpoint.sessionId, prompt, timeoutMs);
      }
    } finally {
      await this.close();
    }
  }

  private activateSession(sessionId: string): void {
    // A desktop worker may be returned to WorkBuddy's prewarm pool while its
    // registry row remains. The macOS deep link asks the renderer to promote
    // that conversation again. Never invoke it for injected test transports.
    if (process.platform !== "darwin" || this.fetchImpl !== globalThis.fetch) return;
    try {
      execFileSync("open", [`workbuddy://chat/${encodeURIComponent(sessionId)}`], {
        stdio: "ignore",
        timeout: 5_000,
      });
    } catch {
      // The subsequent session/load will provide the actionable ACP error.
    }
  }

  async cancel(sessionId: string): Promise<void> {
    if (!this.credentials) return;
    const endpoint = this.connectedEndpoint ?? AcpLiveClient.discover(this.config);
    await this.postRpc(endpoint, { jsonrpc: "2.0", method: "session/cancel", params: { sessionId } }).catch(() => undefined);
    this.aborted = true;
  }

  async close(): Promise<void> {
    const endpoint = this.connectedEndpoint;
    const credentials = this.credentials;
    this.credentials = undefined;
    this.connectedEndpoint = undefined;
    if (!endpoint || !credentials) return;
    const headers: Record<string, string> = { accept: "application/json", "x-codebuddy-request": "1", "acp-connection-id": credentials.connectionId };
    if (credentials.sessionToken) headers["acp-session-token"] = credentials.sessionToken;
    await this.fetchImpl(`${endpoint.baseUrl}/api/v1/acp`, { method: "DELETE", headers }).catch(() => undefined);
  }

  private async connect(endpoint: LiveEndpoint): Promise<void> {
    const response = await this.fetchImpl(`${endpoint.baseUrl}/api/v1/acp/connect`, {
      method: "POST",
      headers: { accept: "application/json", "x-codebuddy-request": "1" },
      signal: AbortSignal.timeout(this.config.requestTimeoutMs),
    });
    const payload = await parseResponse(response);
    if (!response.ok || !payload || typeof payload !== "object") throw new Error(`WorkBuddy ACP connect failed (${response.status})`);
    const body = payload as Record<string, unknown>;
    const data = body.data && typeof body.data === "object" ? body.data as Record<string, unknown> : body;
    if (typeof data.connectionId !== "string" || !data.connectionId) throw new Error("WorkBuddy ACP connect returned no connectionId");
    this.credentials = { connectionId: data.connectionId, sessionToken: typeof data.sessionToken === "string" ? data.sessionToken : undefined };
    this.connectedEndpoint = endpoint;
    this.aborted = false;
  }

  private async rpc(endpoint: LiveEndpoint, method: string, params: Record<string, unknown>, timeoutMs: number): Promise<Record<string, unknown> | undefined> {
    const id = Math.floor(Math.random() * 2_000_000_000);
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const response = await this.postRpc(endpoint, { jsonrpc: "2.0", id, method, params }, controller.signal);
      const messages = await collectSseOrJson(response);
      const message = messages.find((item) => item.id === id) ?? messages.find((item) => item.result !== undefined || item.error !== undefined);
      if (message?.error && typeof message.error === "object") throw new Error(String((message.error as Record<string, unknown>).message ?? `ACP ${method} failed`));
      return message?.result && typeof message.result === "object" ? message.result as Record<string, unknown> : undefined;
    } finally { clearTimeout(timer); }
  }

  private async prompt(endpoint: LiveEndpoint, sessionId: string, prompt: string, timeoutMs: number): Promise<AcpRunResult> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    const id = Math.floor(Math.random() * 2_000_000_000);
    try {
      const response = await this.postRpc(endpoint, {
        jsonrpc: "2.0", id, method: "session/prompt",
        params: { sessionId, prompt: [{ type: "text", text: prompt }] },
      }, controller.signal);
      if (!response.ok) throw new Error(`WorkBuddy ACP prompt failed (${response.status})`);
      const messages = await collectSseOrJson(response, async (message) => {
        if (typeof message.method !== "string" || message.id === undefined) return;
        if (message.method === "session/request_permission" || message.method === "requestPermission") {
          const result = this.permissionResult(message.params);
          await this.postRpc(endpoint, { jsonrpc: "2.0", id: message.id, result });
        } else if (message.method === "elicitation/create") {
          await this.postRpc(endpoint, { jsonrpc: "2.0", id: message.id, result: { action: "cancel" } });
        }
      });
      const protocolError = messages.find((message) => message.error && typeof message.error === "object");
      if (protocolError?.error && typeof protocolError.error === "object") {
        throw new Error(String((protocolError.error as Record<string, unknown>).message ?? "WorkBuddy ACP prompt failed"));
      }
      let text = "";
      let stopReason: string | undefined;
      for (const message of messages) {
        if (message.result && typeof message.result === "object") {
          const result = message.result as Record<string, unknown>;
          if (typeof result.stopReason === "string") stopReason = result.stopReason;
        }
        const params = message.params;
        if (!params || typeof params !== "object") continue;
        const update = (params as Record<string, unknown>).update;
        if (!update || typeof update !== "object") continue;
        const updateBody = update as Record<string, unknown>;
        if (updateBody.sessionUpdate !== "agent_message_chunk") continue;
        const content = updateBody.content;
        const chunk = content && typeof content === "object" ? (content as Record<string, unknown>).text : undefined;
        if (typeof chunk === "string" && text.length < MAX_OUTPUT_CHARS) text += chunk.slice(0, MAX_OUTPUT_CHARS - text.length);
      }
      if (this.aborted) throw new Error("WorkBuddy ACP task cancelled");
      return { text, stopReason };
    } catch (error) {
      if ((error as Error).name === "AbortError") throw new Error("WorkBuddy ACP task timed out");
      throw error;
    } finally { clearTimeout(timer); }
  }

  private async postRpc(endpoint: LiveEndpoint, body: Record<string, unknown>, signal?: AbortSignal): Promise<Response> {
    if (!this.credentials) throw new Error("WorkBuddy ACP is not connected");
    const headers: Record<string, string> = {
      accept: "application/json, text/event-stream",
      "content-type": "application/json",
      "x-codebuddy-request": "1",
      "acp-connection-id": this.credentials.connectionId,
    };
    if (this.credentials.sessionToken) headers["acp-session-token"] = this.credentials.sessionToken;
    return this.fetchImpl(`${endpoint.baseUrl}/api/v1/acp`, { method: "POST", headers, body: JSON.stringify(body), signal });
  }

  private permissionResult(params: unknown): Record<string, unknown> {
    if (this.permissionMode === "allow_once" && params && typeof params === "object") {
      const options = (params as Record<string, unknown>).options;
      if (Array.isArray(options)) {
        const option = options.find((item) => item && typeof item === "object" && (item as Record<string, unknown>).kind === "allow_once" && typeof (item as Record<string, unknown>).optionId === "string");
        if (option && typeof option === "object") return { outcome: { outcome: "selected", optionId: (option as Record<string, unknown>).optionId } };
      }
    }
    return { outcome: { outcome: "cancelled" } };
  }
}

export function validateLoopbackUrl(value: string): string {
  const url = new URL(value);
  if (url.protocol !== "http:" || !url.port || !LOOPBACK_HOSTS.has(url.hostname) || url.username || url.password || url.search || url.hash || (url.pathname !== "/" && url.pathname !== "")) {
    throw new Error("WorkBuddy ACP endpoint must be an HTTP loopback URL");
  }
  return `http://${url.hostname}:${url.port}`;
}

interface RpcMessage { id?: number | string; method?: string; params?: unknown; result?: unknown; error?: unknown }

async function parseResponse(response: Response): Promise<unknown> {
  const text = await response.text();
  if (!text) return undefined;
  try { return JSON.parse(text) as unknown; } catch { return text; }
}

async function collectSseOrJson(response: Response, onMessage?: (message: RpcMessage) => Promise<void>): Promise<RpcMessage[]> {
  const contentType = response.headers.get("content-type") ?? "";
  if (!response.body || !contentType.includes("text/event-stream")) {
    const value = await parseResponse(response);
    if (value && typeof value === "object") return [value as RpcMessage];
    return [];
  }
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let completed = false;
  const messages: RpcMessage[] = [];
  const handle = async (block: string) => {
    const lines = block.split(/\r?\n/);
    const data = lines.filter((line) => line.startsWith("data:")).map((line) => line.slice(5).trimStart()).join("\n");
    if (!data) return;
    try {
      const message = JSON.parse(data) as RpcMessage;
      messages.push(message);
      await onMessage?.(message);
      // ACP keeps the SSE connection available for broadcasts after the
      // JSON-RPC response. The matching result/error is the terminal frame
      // for this request; stop reading there so a healthy task cannot look
      // like a timeout when WorkBuddy leaves the stream open.
      if (message.id !== undefined && (message.result !== undefined || message.error !== undefined)) {
        completed = true;
      }
    } catch { /* keep-alive or malformed frames are ignored */ }
  };
  while (true) {
    const part = await reader.read();
    buffer += decoder.decode(part.value ?? new Uint8Array(), { stream: !part.done });
    const blocks = buffer.split(/\r?\n\r?\n/);
    buffer = blocks.pop() ?? "";
    for (const block of blocks) {
      await handle(block);
      if (completed) break;
    }
    if (completed || part.done) {
      if (completed) await reader.cancel().catch(() => undefined);
      break;
    }
  }
  if (buffer.trim()) await handle(buffer);
  return messages;
}
