import fs from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { LocalMessage } from "./workbuddy-client.js";

export type TaskState = "queued" | "working" | "completed" | "blocked" | "failed" | "cancelled" | "needs_review" | "accepted";

export interface StoredTask {
  taskId: string;
  messageId: string;
  objective: string;
  workspace?: string;
  state: TaskState;
  createdAt: string;
  updatedAt: string;
  lastMessageId?: string;
  report?: TaskReport;
  cancelNote?: string;
  reviewNote?: string;
  reviewedAt?: string;
}

export interface TaskReport {
  status?: string;
  filesChanged: string[];
  commandsRun: string[];
  testResult?: string;
  remainingProblems?: string;
  rawText: string;
}

export type TaskUpdate = Partial<Pick<StoredTask, "state" | "messageId" | "lastMessageId" | "cancelNote">> & {
  report?: TaskReport | null;
  reviewNote?: string | null;
  reviewedAt?: string | null;
};

export class TaskStore {
  private readonly db: DatabaseSync;

  constructor(readonly file: string) {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    this.db = new DatabaseSync(file);
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS tasks (
        task_id TEXT PRIMARY KEY,
        message_id TEXT NOT NULL,
        objective TEXT NOT NULL,
        workspace TEXT,
        state TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        last_message_id TEXT,
        report_json TEXT,
        cancel_note TEXT,
        review_note TEXT,
        reviewed_at TEXT
      );
      CREATE TABLE IF NOT EXISTS messages (
        task_id TEXT NOT NULL,
        message_id TEXT NOT NULL,
        role TEXT NOT NULL,
        content_json TEXT NOT NULL,
        msg_type TEXT,
        created_at TEXT,
        raw_json TEXT NOT NULL,
        PRIMARY KEY (task_id, message_id),
        FOREIGN KEY(task_id) REFERENCES tasks(task_id)
      );
    `);
    // Existing databases predate the review loop. SQLite has no portable
    // CREATE TABLE IF NOT EXISTS migration, so add the optional columns when
    // they are absent and keep old task files usable.
    for (const statement of [
      "ALTER TABLE tasks ADD COLUMN review_note TEXT",
      "ALTER TABLE tasks ADD COLUMN reviewed_at TEXT",
    ]) {
      try { this.db.exec(statement); } catch (error) {
        if (!(error instanceof Error) || !/duplicate column name/i.test(error.message)) throw error;
      }
    }
  }

  close(): void { this.db.close(); }

  createOrGet(task: Omit<StoredTask, "createdAt" | "updatedAt"> & { createdAt?: string }): { task: StoredTask; created: boolean } {
    const existing = this.get(task.taskId);
    if (existing) return { task: existing, created: false };
    const now = task.createdAt ?? new Date().toISOString();
    this.db.prepare(`INSERT INTO tasks (task_id, message_id, objective, workspace, state, created_at, updated_at, last_message_id, report_json, cancel_note)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`).run(
      task.taskId, task.messageId, task.objective, task.workspace ?? null, task.state, now, now,
      task.lastMessageId ?? task.messageId, task.report ? JSON.stringify(task.report) : null, task.cancelNote ?? null,
    );
    return { task: this.get(task.taskId)!, created: true };
  }

  get(taskId: string): StoredTask | undefined {
    const row = this.db.prepare("SELECT * FROM tasks WHERE task_id = ?").get(taskId) as Record<string, unknown> | undefined;
    return row ? rowToTask(row) : undefined;
  }

  update(taskId: string, patch: TaskUpdate): StoredTask {
    const current = this.get(taskId);
    if (!current) throw new Error(`Unknown task: ${taskId}`);
    const updatedAt = new Date().toISOString();
    this.db.prepare(`UPDATE tasks SET state = ?, message_id = ?, updated_at = ?, last_message_id = ?, report_json = ?, cancel_note = ?, review_note = ?, reviewed_at = ? WHERE task_id = ?`).run(
      patch.state ?? current.state,
      patch.messageId ?? current.messageId,
      updatedAt,
      patch.lastMessageId ?? current.lastMessageId ?? null,
      patch.report === undefined ? (current.report ? JSON.stringify(current.report) : null) : patch.report === null ? null : JSON.stringify(patch.report),
      patch.cancelNote ?? current.cancelNote ?? null,
      patch.reviewNote === undefined ? current.reviewNote ?? null : patch.reviewNote,
      patch.reviewedAt === undefined ? current.reviewedAt ?? null : patch.reviewedAt,
      taskId,
    );
    return this.get(taskId)!;
  }

  addMessages(taskId: string, messages: LocalMessage[]): number {
    const statement = this.db.prepare(`INSERT OR IGNORE INTO messages (task_id, message_id, role, content_json, msg_type, created_at, raw_json)
      VALUES (?, ?, ?, ?, ?, ?, ?)`);
    let inserted = 0;
    for (const message of messages) {
      const result = statement.run(taskId, message.message_id, message.role, JSON.stringify(message.content ?? []), message.msg_type ?? null, message.created_at ?? null, JSON.stringify(message));
      if (Number(result.changes) > 0) inserted += 1;
    }
    return inserted;
  }

  listMessages(taskId: string, limit = 100): LocalMessage[] {
    const rows = this.db.prepare("SELECT raw_json FROM messages WHERE task_id = ? ORDER BY rowid ASC LIMIT ?").all(taskId, Math.min(Math.max(limit, 1), 500)) as Array<{ raw_json: string }>;
    return rows.map((row) => JSON.parse(row.raw_json) as LocalMessage);
  }
}

function rowToTask(row: Record<string, unknown>): StoredTask {
  return {
    taskId: String(row.task_id),
    messageId: String(row.message_id),
    objective: String(row.objective),
    workspace: row.workspace == null ? undefined : String(row.workspace),
    state: String(row.state) as TaskState,
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
    lastMessageId: row.last_message_id == null ? undefined : String(row.last_message_id),
    report: row.report_json ? JSON.parse(String(row.report_json)) as TaskReport : undefined,
    cancelNote: row.cancel_note == null ? undefined : String(row.cancel_note),
    reviewNote: row.review_note == null ? undefined : String(row.review_note),
    reviewedAt: row.reviewed_at == null ? undefined : String(row.reviewed_at),
  };
}
