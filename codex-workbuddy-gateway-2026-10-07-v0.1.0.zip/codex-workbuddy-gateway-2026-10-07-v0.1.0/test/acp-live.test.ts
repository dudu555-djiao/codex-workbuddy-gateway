import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { AcpLiveClient, validateLoopbackUrl } from "../src/acp-live.js";
import type { Config } from "../src/config.js";

function config(workbuddyConfigDir: string): Config {
  return {
    backend: "desktop-acp",
    apiBaseUrl: "https://test.workbuddy",
    tokenFile: "/tmp/unused-workbuddy-token.json",
    dbFile: "/tmp/unused-workbuddy.sqlite",
    oauthRedirectUri: "http://127.0.0.1:8787/oauth/callback",
    oauthPort: 8787,
    oauthScopes: "",
    requestTimeoutMs: 1000,
    cliElectronPath: "/tmp/electron",
    cliScriptPath: "/tmp/codebuddy",
    cliPermissionMode: "acceptEdits",
    acpPermissionMode: "deny",
    gatewayUrl: "http://127.0.0.1:64523",
    workbuddyConfigDir,
  };
}

test("discovers an interactive loopback session and probes ACP", async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "workbuddy-acp-"));
  const sessions = path.join(root, "sessions");
  fs.mkdirSync(sessions);
  fs.writeFileSync(path.join(sessions, "current.json"), JSON.stringify({
    kind: "interactive", pid: process.pid, sessionId: "interactive-test", endpoint: "http://127.0.0.1:64523", cwd: "/tmp", lastHeartbeat: Date.now(),
  }));
  const calls: string[] = [];
  const fakeFetch: typeof fetch = async (input, init = {}) => {
    calls.push(`${init.method ?? "GET"} ${String(input)}`);
    if (init.method === "DELETE") return new Response("", { status: 200 });
    return new Response(JSON.stringify({ connectionId: "test-connection", sessionToken: "test-token" }), { status: 200, headers: { "content-type": "application/json" } });
  };
  const result = await new AcpLiveClient(config(root), "deny", fakeFetch).health();
  assert.equal(result.online, true);
  assert.equal(result.endpoint.sessionId, "interactive-test");
  assert.deepEqual(calls.map((call) => call.split(" ")[0]), ["POST", "DELETE"]);
  assert.equal(validateLoopbackUrl("http://localhost:64523"), "http://localhost:64523");
  assert.throws(() => validateLoopbackUrl("https://127.0.0.1:64523"), /loopback/);
  fs.rmSync(root, { recursive: true, force: true });
});

test("loads a prewarmed session once and returns the ACP assistant text", async () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "workbuddy-acp-run-"));
  const sessions = path.join(root, "sessions");
  fs.mkdirSync(sessions);
  fs.writeFileSync(path.join(sessions, "current.json"), JSON.stringify({
    kind: "interactive", pid: process.pid, sessionId: "interactive-test", endpoint: "http://127.0.0.1:64523", cwd: "/tmp", lastHeartbeat: Date.now(),
  }));
  const methods: string[] = [];
  let promptAttempts = 0;
  const sse = (message: unknown) => new Response(`:ok\n\nevent: message\ndata: ${JSON.stringify(message)}\n\n`, { status: 200, headers: { "content-type": "text/event-stream" } });
  const fakeFetch: typeof fetch = async (input, init = {}) => {
    const url = String(input);
    if (init.method === "DELETE") return new Response("", { status: 200 });
    if (url.endsWith("/connect")) return new Response(JSON.stringify({ connectionId: "test-connection", sessionToken: "test-token" }), { status: 200, headers: { "content-type": "application/json" } });
    const body = JSON.parse(String(init.body)) as { id: number; method: string };
    methods.push(body.method);
    if (body.method === "session/prompt") {
      promptAttempts += 1;
      if (promptAttempts === 1) return sse({ jsonrpc: "2.0", id: body.id, error: { code: -32603, message: "Session not found: interactive-test" } });
      return new Response([
        ":ok",
        "",
        `event: message\ndata: ${JSON.stringify({ jsonrpc: "2.0", method: "session/update", params: { update: { sessionUpdate: "agent_message_chunk", content: { type: "text", text: "BRIDGE_OK" } } } })}`,
        "",
        `event: message\ndata: ${JSON.stringify({ jsonrpc: "2.0", id: body.id, result: { stopReason: "end_turn" } })}`,
        "",
      ].join("\n"), { status: 200, headers: { "content-type": "text/event-stream" } });
    }
    return sse({ jsonrpc: "2.0", id: body.id, result: {} });
  };
  try {
    const result = await new AcpLiveClient(config(root), "deny", fakeFetch).run("hello", undefined, 5_000);
    assert.equal(result.text, "BRIDGE_OK");
    assert.deepEqual(methods, ["initialize", "session/prompt", "session/load", "session/prompt"]);
  } finally {
    fs.rmSync(root, { recursive: true, force: true });
  }
});
